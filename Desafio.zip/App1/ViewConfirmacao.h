//
//  ViewConfirmacao.h
//  App1
//
//  Created by Victor de Lima on 14/05/14.
//  Copyright (c) 2014 Victor de Lima. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewConfirmacao : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *btnOK;

-(IBAction)clickOK:(id)sender;
-(IBAction)novoCadastro:(id)sender;

@end
